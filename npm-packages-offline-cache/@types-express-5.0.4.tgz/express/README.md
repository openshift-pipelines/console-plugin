# Installation
> `npm install --save @types/express`

# Summary
This package contains type definitions for express (http://expressjs.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express.

### Additional Details
 * Last updated: Fri, 24 Oct 2025 04:02:41 GMT
 * Dependencies: [@types/body-parser](https://npmjs.com/package/@types/body-parser), [@types/express-serve-static-core](https://npmjs.com/package/@types/express-serve-static-core), [@types/serve-static](https://npmjs.com/package/@types/serve-static)

# Credits
These definitions were written by [Boris Yankov](https://github.com/borisyankov), [Puneet Arora](https://github.com/puneetar), [Dylan Frankland](https://github.com/dfrankland), and [Sebastian Beltran](https://github.com/bjohansebas).
